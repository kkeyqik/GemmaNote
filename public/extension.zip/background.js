// Global state is now handled in chrome.storage.local because service workers sleep during long generation times.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'START_GENERATION_QUEUE') {
    let { tasks } = message.payload;
    
    // Mark as pending
    tasks = tasks.map(t => ({ ...t, status: 'pending' }));
    
    // Start the first one
    const firstTask = tasks.shift();
    
    chrome.storage.local.set({
      currentTask: firstTask,
      taskQueue: tasks
    }, () => {
      // Open Gemini and Group it
      chrome.tabs.create({ url: 'https://gemini.google.com/app', active: true }, (tab) => {
        const newGeminiTabId = tab.id;
        
        // Create a Tab Group if the API is available
        if (chrome.tabs.group) {
           chrome.tabs.group({ tabIds: newGeminiTabId }, (groupId) => {
             chrome.tabGroups.update(groupId, { color: 'blue', title: 'AI Writer' });
             chrome.storage.local.set({ geminiTabId: newGeminiTabId, currentGroupId: groupId });
           });
        } else {
             chrome.storage.local.set({ geminiTabId: newGeminiTabId });
        }
      });
    });
  } 
  
  else if (message.type === 'GENERATION_COMPLETE') {
    // Process next item in queue
    chrome.storage.local.get(['taskQueue'], (res) => {
      const queue = res.taskQueue || [];
      if (queue.length > 0) {
        const nextRaw = queue.shift();
        const nextTask = { ...nextRaw, status: 'pending' };
        
        chrome.storage.local.set({
          currentTask: nextTask,
          taskQueue: queue
        }, () => {
          // Tell popup we are on next task
          chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', text: `Processing next topic... (${queue.length} left)` }).catch(() => {});
        });
      } else {
        // Queue finished
        chrome.storage.local.set({ currentTask: null });
        chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', text: `All posts generated!` }).catch(() => {});
        chrome.runtime.sendMessage({ type: 'GENERATION_COMPLETE' }).catch(() => {});
        chrome.storage.local.get(['geminiTabId'], (r) => {
          if (r.geminiTabId) {
            chrome.tabs.sendMessage(r.geminiTabId, { type: 'QUEUE_FINISHED' }).catch(() => {});
          }
        });
      }
    });
  }
  
  else if (message.type === 'OPEN_GEMMANOTE') {
    const { id } = message.payload;
    // Open in a new background tab
    chrome.tabs.create({ url: `https://gemma-note.vercel.app/editor?id=${encodeURIComponent(id)}`, active: false }, (tab) => {
      // Add the new tab to the existing AI Writer tab group
      chrome.storage.local.get(['currentGroupId'], (res) => {
        if (res.currentGroupId && chrome.tabs.group) {
          chrome.tabs.group({ tabIds: tab.id, groupId: res.currentGroupId }).catch(() => {});
        }
      });
    });
  } 
  
  else if (message.type === 'STOP_GENERATION') {
    chrome.storage.local.set({ currentTask: null, taskQueue: [] });
    chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', text: 'Generation stopped.' }).catch(() => {});
  }
  
  else if (message.type === 'STATUS_UPDATE' || message.type === 'GENERATION_ERROR') {
    // Forward to popup if it's open
    chrome.runtime.sendMessage(message).catch(() => {});
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.get(['geminiTabId'], (res) => {
    if (tabId === res.geminiTabId) {
      chrome.storage.local.set({ currentTask: null, taskQueue: [], geminiTabId: null });
      chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', text: 'Queue cancelled (Gemini tab closed).' }).catch(() => {});
    }
  });
});
