document.addEventListener('DOMContentLoaded', async () => {
  const step1 = document.getElementById('step-1');
  const step2 = document.getElementById('step-2');
  const authError = document.getElementById('auth-error');
  const loginBtn = document.getElementById('loginBtn');
  const numBlogsInput = document.getElementById('numBlogs');
  const wordCountInput = document.getElementById('wordCount');
  
  const nextBtn = document.getElementById('nextBtn');
  const backBtn = document.getElementById('backBtn');
  const generateBtn = document.getElementById('generateBtn');
  
  const topicsContainer = document.getElementById('topicsContainer');
  const statusContainer = document.getElementById('statusContainer');
  const statusText = document.getElementById('statusText');
  const resetQueueBtn = document.getElementById('resetQueueBtn');

  let tagData = []; // Array of string arrays for keywords
  let intentData = []; // Per-blog intent/style overrides

  // Auth check function
  async function checkAuth() {
    try {
      const res = await fetch('https://gemma-note.vercel.app/api/account');
      if (!res.ok) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  // Initial Auth Check
  const isAuthenticated = await checkAuth();
  if (!isAuthenticated) {
    authError.classList.remove('hidden');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://gemma-note.vercel.app/sign-in' });
      });
    }
    return; // Stop execution
  }

  step1.classList.remove('hidden');

  // Load state if processing
  chrome.storage.local.get(['currentTask', 'taskQueue'], (res) => {
    if (res.currentTask) {
      step1.classList.add('hidden');
      step2.classList.add('hidden');
      statusContainer.classList.remove('hidden');
      const queueLen = res.taskQueue ? res.taskQueue.length : 0;
      statusText.textContent = `Processing topic... (${queueLen} left in queue)`;
      generateBtn.disabled = true;
    }
  });

  // Handle messages
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATUS_UPDATE') {
      statusText.textContent = message.text;
    } else if (message.type === 'GENERATION_COMPLETE') {
      statusText.textContent = 'Queue Finished!';
      setTimeout(() => {
        statusContainer.classList.add('hidden');
        step1.classList.remove('hidden');
        generateBtn.disabled = false;
        generateBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg> Start Generating';
      }, 3000);
    }
  });

  resetQueueBtn.addEventListener('click', () => {
    chrome.storage.local.set({ currentTask: null, taskQueue: [] }, () => {
      statusContainer.classList.add('hidden');
      step1.classList.remove('hidden');
      generateBtn.disabled = false;
      generateBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg> Start Generating';
    });
    chrome.runtime.sendMessage({ type: 'STOP_GENERATION' });
  });

  // Flow control
  nextBtn.addEventListener('click', () => {
    let numBlogs = parseInt(numBlogsInput.value, 10);
    if (isNaN(numBlogs) || numBlogs < 1) numBlogs = 1;
    if (numBlogs > 10) numBlogs = 10;
    
    // Build UI for topics
    topicsContainer.innerHTML = '';
    tagData = Array(numBlogs).fill().map(() => []);
    const applyAll = document.getElementById('applyAllIntent').checked;
    const defaultIntent = document.getElementById('defaultIntent').value;
    const defaultStyle = document.getElementById('defaultStyle').value;
    intentData = Array(numBlogs).fill().map(() => ({ intent: defaultIntent, style: defaultStyle }));

    for (let i = 0; i < numBlogs; i++) {
      const card = document.createElement('div');
      card.className = 'topic-card';
      
      let intentHtml = '';
      if (!applyAll) {
        intentHtml = `
          <div class="form-group">
            <label>Intent & Style</label>
            <div class="per-blog-intent">
              <select class="blog-intent" data-index="${i}">
                <option value="informational" ${defaultIntent === 'informational' ? 'selected' : ''}>Informational</option>
                <option value="commercial" ${defaultIntent === 'commercial' ? 'selected' : ''}>Commercial</option>
                <option value="transactional" ${defaultIntent === 'transactional' ? 'selected' : ''}>Transactional</option>
                <option value="navigational" ${defaultIntent === 'navigational' ? 'selected' : ''}>Navigational</option>
              </select>
              <select class="blog-style" data-index="${i}">
                <option value="standard" ${defaultStyle === 'standard' ? 'selected' : ''}>Standard Blog</option>
                <option value="listicle" ${defaultStyle === 'listicle' ? 'selected' : ''}>Listicle (Top X)</option>
                <option value="howto" ${defaultStyle === 'howto' ? 'selected' : ''}>How-To / Tutorial</option>
                <option value="opinion" ${defaultStyle === 'opinion' ? 'selected' : ''}>Opinion / Editorial</option>
                <option value="comparison" ${defaultStyle === 'comparison' ? 'selected' : ''}>Comparison (X vs Y)</option>
                <option value="news" ${defaultStyle === 'news' ? 'selected' : ''}>News / Trending</option>
                <option value="casestudy" ${defaultStyle === 'casestudy' ? 'selected' : ''}>Case Study</option>
              </select>
            </div>
          </div>
        `;
      }
      
      card.innerHTML = `
        <h4>Blog ${i + 1}</h4>
        <div class="form-group">
          <label>Topic</label>
          <input type="text" class="topic-val" placeholder="e.g., Top 10 tips for remote work">
        </div>
        <div class="form-group">
          <label>Keywords</label>
          <div class="tag-input-container" id="tag-container-${i}">
            <input type="text" placeholder="Type keyword and press Enter or Comma">
          </div>
        </div>
        ${intentHtml}
      `;
      topicsContainer.appendChild(card);

      // Per-blog intent change handlers
      const blogIntentSel = card.querySelector('.blog-intent');
      const blogStyleSel = card.querySelector('.blog-style');
      if (blogIntentSel) {
        blogIntentSel.addEventListener('change', (e) => {
          intentData[i].intent = e.target.value;
        });
      }
      if (blogStyleSel) {
        blogStyleSel.addEventListener('change', (e) => {
          intentData[i].style = e.target.value;
        });
      }
      
      const container = card.querySelector(`#tag-container-${i}`);
      const input = container.querySelector('input');
      
      // Tag engine
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ',') {
          e.preventDefault();
          const val = input.value.trim().replace(/,$/, '');
          if (val && !tagData[i].includes(val)) {
            tagData[i].push(val);
            renderTags(i, container);
          }
          input.value = '';
        } else if (e.key === 'Backspace' && input.value === '' && tagData[i].length > 0) {
          tagData[i].pop();
          renderTags(i, container);
        }
      });
      
      // Make container click focus input
      container.addEventListener('click', () => input.focus());
    }

    step1.classList.add('hidden');
    step2.classList.remove('hidden');
  });

  backBtn.addEventListener('click', () => {
    step2.classList.add('hidden');
    step1.classList.remove('hidden');
  });

  function renderTags(index, container) {
    const existingTags = container.querySelectorAll('.tag');
    existingTags.forEach(t => t.remove());
    
    const input = container.querySelector('input');
    
    tagData[index].forEach((tag, tagIndex) => {
      const span = document.createElement('span');
      span.className = 'tag';
      span.innerHTML = `${tag} <span class="remove-tag">&times;</span>`;
      container.insertBefore(span, input);
      
      span.querySelector('.remove-tag').addEventListener('click', (e) => {
        e.stopPropagation();
        tagData[index].splice(tagIndex, 1);
        renderTags(index, container);
      });
    });
  }

  generateBtn.addEventListener('click', () => {
    const minWords = parseInt(wordCountInput.value, 10);
    const topicsInputs = document.querySelectorAll('.topic-val');
    
    let tasks = [];
    let hasError = false;

    topicsInputs.forEach((input, i) => {
      const topic = input.value.trim();
      if (!topic) {
        hasError = true;
      }
      tasks.push({
        topic,
        keywords: tagData[i].join(', '),
        minWords,
        intent: intentData[i].intent,
        style: intentData[i].style
      });
    });

    if (hasError) {
      alert("Please provide a topic for all blogs.");
      return;
    }

    // Start generation
    generateBtn.disabled = true;
    generateBtn.textContent = 'Starting...';
    step2.classList.add('hidden');
    statusContainer.classList.remove('hidden');
    statusText.textContent = `Queuing ${tasks.length} post(s)...`;

    chrome.runtime.sendMessage({
      type: 'START_GENERATION_QUEUE',
      payload: { tasks }
    });
  });
});
