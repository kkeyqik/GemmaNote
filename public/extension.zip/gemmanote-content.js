// Listens for window messages from the React app if needed, 
// or injects data directly into the DOM for the Next.js app to pick up.

window.addEventListener('message', (event) => {
  // This bridge is intentionally same-origin. It must never service messages
  // from an arbitrary page that happens to have the extension installed.
  if (event.origin !== window.location.origin || event.source !== window) return;
  // If the React app sends a "READY" message, we fetch the ID from the URL
  if (event.data && event.data.type === 'GEMMANOTE_READY' && event.data.source === 'gemmanote-webapp') {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    
    if (id && /^[A-Za-z0-9_-]{1,128}$/.test(id)) {
      chrome.storage.local.get(['history'], (res) => {
        const history = res.history || [];
        const post = history.find(p => p.id === id);
        
        if (post) {
          window.postMessage({ type: 'BLOG_POST_DATA', source: 'gemmanote-extension', payload: post }, window.location.origin);
        }
      });
    }
  }
});
