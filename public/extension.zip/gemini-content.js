let task = null;

chrome.storage.local.get(['currentTask'], async (result) => {
  if (result.currentTask && result.currentTask.status === 'pending') {
    task = result.currentTask;
    chrome.storage.local.set({ currentTask: { ...task, status: 'in-progress' } });
    await sleep(3000); // Wait for page to settle
    startProcess();
  }
});

chrome.storage.onChanged.addListener(async (changes, namespace) => {
  if (namespace === 'local' && changes.currentTask) {
    const newTask = changes.currentTask.newValue;
      if (newTask && newTask.status === 'pending') {
        task = newTask;
        chrome.storage.local.set({ currentTask: { ...task, status: 'in-progress' } });
        
        // We seamlessly click the New Chat button to start fresh without a heavy hard reload
        const newChatBtn = document.querySelector('a[href="/app"], button[aria-label="New chat"], div[data-test-id="new-chat-button"]');
        if (newChatBtn) newChatBtn.click();
        
        await sleep(3000); // Wait for fresh UI
        startProcess();
      }
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'QUEUE_FINISHED') {
      playCompletionChime();
      const overlay = document.getElementById('gemmanote-overlay');
      if (overlay) {
        // Change the overlay to a success state
        const centerBar = overlay.children[1]; // The bottom center bar
        if (centerBar) {
          centerBar.innerHTML = `
            <div style="width: 18px; height: 18px; border-radius: 50%; background: #10b981; display: flex; align-items: center; justify-content: center; color: white;">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <span style="font-size: 14px; font-weight: 500; letter-spacing: 0.3px;">All Blog Posts Completed!</span>
            <button id="gb-close-btn" style="
              background: rgba(255,255,255,0.1); color: white; border: 1px solid rgba(255,255,255,0.2);
              padding: 6px 16px; border-radius: 999px; font-size: 12px; font-weight: 600;
              cursor: pointer; transition: all 0.2s;
            ">Close</button>
          `;
          
          document.getElementById('gb-close-btn').addEventListener('click', () => {
            overlay.remove();
          });
        }
      }
    }
  });

function playCompletionChime() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    
    // Two-note chime: a gentle "ding-dong"
    const notes = [
      { freq: 587.33, start: 0,    dur: 0.25 },  // D5
      { freq: 880.00, start: 0.15, dur: 0.4  }    // A5
    ];
    
    notes.forEach(({ freq, start, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.value = freq;
      
      // Soft envelope: fade in, sustain, fade out
      gain.gain.setValueAtTime(0, ctx.currentTime + start);
      gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + start + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur);
    });
    
    // Clean up after the chime finishes
    setTimeout(() => ctx.close(), 1000);
  } catch (e) {
    console.log('[GemmaNote] Could not play chime:', e);
  }
}

function sleep(ms) { 
  return new Promise(resolve => {
    let elapsed = 0;
    const interval = setInterval(() => {
      elapsed += 100;
      if (window._gbStopFlag) {
        clearInterval(interval);
        resolve(); // Or throw, but this makes it safe
      }
      if (elapsed >= ms) {
        clearInterval(interval);
        resolve();
      }
    }, 100);
  });
}

function sendStatus(text) {
  console.log("[GemmaNote]", text);
  chrome.runtime.sendMessage({ type: 'STATUS_UPDATE', text }).catch(() => {});
}

async function getEditor() {
  for (let i = 0; i < 20; i++) {
    const editor = document.querySelector('rich-textarea [contenteditable="true"]') ||
                   document.querySelector('.ProseMirror') || 
                   document.querySelector('div[data-placeholder="Enter a prompt here"]') ||
                   document.querySelector('div[aria-label="Enter a prompt here"]');
    if (editor) return editor;
    await sleep(500);
  }
  throw new Error("Could not find chat input box.");
}

async function typeText(editor, text) {
  editor.focus();
  
  // Method 1: execCommand
  document.execCommand('insertText', false, text);
  
  // Method 2: fallback if it didn't type
  if (!editor.textContent.includes(text.substring(0, 5))) {
    if (editor.tagName === 'DIV' || editor.tagName === 'P') {
        editor.innerHTML = `<p>${text}</p>`;
    } else {
        editor.value = text;
    }
  }

  // Dispatch events to wake up React/Angular
  editor.dispatchEvent(new Event('input', { bubbles: true }));
  editor.dispatchEvent(new Event('change', { bubbles: true }));
  editor.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', code: 'Space', bubbles: true }));
  editor.dispatchEvent(new KeyboardEvent('keyup', { key: ' ', code: 'Space', bubbles: true }));
}

async function clickSend() {
  // Strictly only click buttons labeled "Send" — never the Stop button or anything else.
  const selectors = [
    'button[aria-label="Send message"]',
    'button[aria-label*="Send"]',
    '.send-button'
  ];
  
  // Retry for up to 15 seconds waiting for the Send button to exist and be enabled.
  // This replaces the old dangerous Enter-key fallback that could hit "Stop generating".
  for (let attempt = 0; attempt < 30; attempt++) {
    for (let sel of selectors) {
      let btn = document.querySelector(sel);
      if (btn) {
        if (btn.tagName !== 'BUTTON') btn = btn.closest('button') || btn;
        if (btn && !btn.disabled) {
          btn.click();
          return true;
        }
      }
    }
    await sleep(500);
  }
  
  throw new Error("Send button not found or not enabled after 15 seconds. Aborting to avoid interrupting Gemini.");
}


function extractLatestResponse() {
  // Use selectors that are PROVEN to work in Gemini's DOM.
  // message-content and .markdown are known to match. We grab the LAST one
  // (which is always the model's response, since it renders after the user's prompt).
  const selectors = [
      'message-content',
      '.markdown',
      'model-response',
      '[data-message-author="model"]',
      '[data-test-id="model-response"]',
      '.response-content',
      '.reply-message'
  ];
  
  for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      if (els.length > 0) {
          for (let i = els.length - 1; i >= 0; i--) {
              if (els[i].innerText && els[i].innerText.trim().length > 10) {
                  const clone = els[i].cloneNode(true);
                  const junk = clone.querySelectorAll('button, svg, .google-symbols, .icon, [role="button"], clipboard-copy, img');
                  junk.forEach(el => el.remove());
                  
                  let textContent = clone.innerText.trim();
                  textContent = textContent.replace(/Gemini is AI and can make mistakes\..*/gi, '').trim();
                  textContent = textContent.replace(/Gemini may display inaccurate info\..*/gi, '').trim();
                  
                  return {
                      text: textContent,
                      html: clone.innerHTML.trim()
                  };
              }
          }
      }
  }
  return { text: "", html: "" };
}

async function waitForResponse() {
  // Fast, robust approach:
  // 1. Brief 3s pause for Gemini to begin processing
  // 2. Poll every 1 second, comparing text LENGTH (immune to dynamic DOM changes)
  // 3. hasSeenGrowth guard: won't declare completion until text has actually grown
  //    (prevents mistaking a stable user prompt for a finished response)
  // 4. After growth is observed, if text length is unchanged for 7 consecutive
  //    seconds, Gemini is done. (Gemini rarely pauses >3-4s during generation)
  
  sendStatus("Waiting for Gemini response...");
  await sleep(3000); // Brief pause for Gemini to start
  
  let lastLength = 0;
  let stableCount = 0;
  let hasSeenGrowth = false;
  let finalObj = { text: "", html: "" };

  for (let i = 0; i < 600; i++) { // Max wait 10 minutes
    if (window._gbStopFlag) throw new Error("Stopped by user");
    
    finalObj = extractLatestResponse();
    const currentLength = finalObj.text.length;

    // Track if we've ever seen the text grow — proves the model IS generating
    if (currentLength > lastLength && lastLength > 0) {
        hasSeenGrowth = true;
        sendStatus(`Gemini is writing... (${currentLength} chars)`);
    }

    // Declare completion when:
    // (a) text growth was observed (model generated something)
    // (b) text > 200 chars (not a UI artifact)
    // (c) length stable for 7 consecutive seconds
    if (hasSeenGrowth && currentLength > 200 && currentLength === lastLength) {
        stableCount++;
        if (stableCount >= 7) {
            break;
        }
    } else {
        stableCount = 0;
    }
    
    lastLength = currentLength;
    await sleep(1000);
  }
  
  return finalObj;
}

function countWords(str) {
  return str.trim().split(/\s+/).filter(word => word.length > 0).length;
}

function showCometOverlay() {
  if (document.getElementById('gemmanote-overlay')) return;
  const overlay = document.createElement('div');
  overlay.id = 'gemmanote-overlay';
  overlay.innerHTML = `
    <!-- Edge Gradient Overlay -->
    <div style="
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      pointer-events: none; z-index: 9999998;
      box-shadow: inset 0 0 150px 30px rgba(99, 102, 241, 0.15);
    "></div>
    
    <!-- Bottom Center Bar -->
    <div style="
      position: fixed; bottom: 32px; left: 50%; transform: translateX(-50%);
      background: #0f172a; color: white; padding: 12px 24px;
      border-radius: 999px; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255,255,255,0.1);
      display: flex; align-items: center; gap: 20px;
      z-index: 9999999; font-family: 'Inter', sans-serif;
    ">
      <div style="
        width: 16px; height: 16px; border: 2px solid rgba(99, 102, 241, 0.3);
        border-top-color: #818cf8; border-radius: 50%;
        animation: gb-spin 1s linear infinite;
      "></div>
      
      <span style="font-size: 14px; font-weight: 500; letter-spacing: 0.3px;">GemmaNote is Working...</span>
      
      <button id="gb-stop-btn" style="
        background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2);
        padding: 6px 12px; border-radius: 999px; font-size: 12px; font-weight: 600;
        cursor: pointer; transition: all 0.2s; display: flex; align-items: center; gap: 4px;
      ">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 9h6v6H9z"/></svg>
        Stop
      </button>
      
      <style>
        @keyframes gb-spin { to { transform: rotate(360deg); } }
        #gb-stop-btn:hover { background: #ef4444; color: white; }
      </style>
    </div>
  `;
  document.body.appendChild(overlay);
  
  document.getElementById('gb-stop-btn').addEventListener('click', () => {
    window._gbStopFlag = true;
    chrome.runtime.sendMessage({ type: 'STOP_GENERATION' });
    overlay.remove();
  });
}

async function startProcess() {
  try {
    window._gbStopFlag = false; // Reset stop flag for each blog run
    showCometOverlay();
    sendStatus("Finding chat box...");
    const editor = await getEditor();
    
    sendStatus("Typing prompt...");
    // Build intent-aware opening instruction
    const intentMap = {
      informational: 'Write an informational, educational blog post',
      commercial: 'Write a commercial blog post that helps readers evaluate and compare products/services. Include pros, cons, pricing insights, and buying considerations',
      transactional: 'Write a conversion-focused blog post that guides readers toward taking action (buying, signing up, downloading). Include clear CTAs, urgency, and value propositions',
      navigational: 'Write a brand-focused, authoritative blog post that positions the subject as the go-to resource. Include trust signals and direct references'
    };
    const styleMap = {
      standard: '',
      listicle: ' Format it as a numbered listicle (Top X / Best X style) with a compelling intro and a brief wrap-up.',
      howto: ' Structure it as a step-by-step how-to guide with clear, actionable instructions for each step.',
      opinion: ' Write it as a personal opinion/editorial piece with a strong thesis, supporting arguments, and your unique perspective.',
      comparison: ' Structure it as a detailed comparison (X vs Y) with categories, pros/cons for each, and a clear recommendation.',
      news: ' Write it as a news/trending analysis piece covering recent developments, their impact, and what to expect next.',
      casestudy: ' Frame it as a real-world case study with background, challenges, solutions implemented, and measurable results.'
    };
    
    const intentInstruction = intentMap[task.intent] || intentMap.informational;
    const styleInstruction = styleMap[task.style] || '';
    
    let prompt = `${intentInstruction} about: "${task.topic}".${styleInstruction} `;
    prompt += `Length: at least ${task.minWords} words. Do not stop until you reach this minimum. `;
    prompt += `\n\nCRITICAL WRITING STYLE RULES — your output MUST follow ALL of these:\n`;
    prompt += `1. WRITE LIKE A REAL HUMAN BLOGGER, not an AI. Vary your sentence length wildly — mix very short punchy sentences with longer flowing ones. Real humans don't write every sentence the same length.\n`;
    prompt += `2. Use contractions naturally (don't, won't, it's, they're, you'll). Nobody writes "do not" and "it is" in a casual blog.\n`;
    prompt += `3. NEVER use these overused AI phrases: "In today's digital age", "In the ever-evolving", "It's important to note", "In conclusion", "dive in", "delve", "landscape", "realm", "leverage", "harness", "game-changer", "navigate", "robust", "comprehensive guide", "let's explore", "without further ado", "in this article we will". These are dead giveaways of AI writing.\n`;
    prompt += `4. Include 2-3 personal touches: brief anecdotes, opinions, mild humor, rhetorical questions, or moments of self-doubt ("I'll be honest, I wasn't sure about this at first"). Real bloggers share their perspective.\n`;
    prompt += `5. Start paragraphs differently each time. Don't begin multiple paragraphs with the same structure. Mix it up with questions, statements, single-word openers, quotes, or jumping straight into a story.\n`;
    prompt += `6. Occasionally break grammar rules like a real person: start a sentence with "And" or "But", use a sentence fragment for emphasis, or throw in an em dash — like this — for a natural pause.\n`;
    prompt += `7. DON'T over-structure with too many headers and bullet points. Real blog posts flow conversationally. Use headers sparingly and naturally.\n`;
    prompt += `8. The content must be 100% original and unique. Do not use generic filler phrasing. Write with genuine expertise and a strong personal voice.\n`;
    if (task.keywords) {
      prompt += `9. Weave these SEO keywords naturally into the text (don't force them): ${task.keywords}.\n`;
    }
    await typeText(editor, prompt);
    
    sendStatus("Clicking send...");
    await clickSend();
    
    let responseObj = await waitForResponse();
    let fullHtml = responseObj.html;
    let fullText = responseObj.text;
    let currentWords = countWords(fullText);
    
    // Continuation Loop
    let iterations = 0;
    while (currentWords < task.minWords && iterations < 3) {
      if (window._gbStopFlag) throw new Error("Stopped by user");
      sendStatus(`Current words: ${currentWords}/${task.minWords}. Asking to continue...`);
      const diff = task.minWords - currentWords;
      const editor2 = await getEditor();
      await typeText(editor2, `You only wrote ${currentWords} words, which is below the minimum requirement. Please continue the blog post exactly from where you left off, adding at least ${diff} more words to reach the goal.`);
      
      await clickSend();
      
      sendStatus("Waiting for continuation...");
      let continuationObj = await waitForResponse();
      fullHtml += "<br><br>" + continuationObj.html;
      fullText += "\n\n" + continuationObj.text;
      currentWords = countWords(fullText);
      iterations++;
    }
    
    sendStatus(`Finished! Total words: ${currentWords}`);
    
    // Save to history
    const id = Date.now().toString();
    const newPost = {
      id,
      topic: task.topic,
      keywords: task.keywords,
      minWords: task.minWords,
      actualWords: currentWords,
      content: fullHtml,
      timestamp: Date.now()
    };
    
    chrome.storage.local.get(['history'], (res) => {
      const history = res.history || [];
      history.unshift(newPost);
      chrome.storage.local.set({ history }, () => {
        chrome.runtime.sendMessage({ type: 'GENERATION_COMPLETE' });
        // Open GemmaNote with the generated post.
        chrome.runtime.sendMessage({ type: 'OPEN_GEMMANOTE', payload: { id } });
      });
    });
    
  } catch (error) {
    if (error.message === "Stopped by user") {
      sendStatus("Generation stopped.");
    } else {
      console.error("[GemmaNote] Error:", error);
      chrome.runtime.sendMessage({ type: 'GENERATION_ERROR', error: error.message });
    }
    chrome.storage.local.set({ currentTask: null });
  }
}
